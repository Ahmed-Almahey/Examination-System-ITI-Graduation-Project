﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace GraduationITI
{
    public partial class Form3 : Form
    {
        ExaminationSystemEntities db = new ExaminationSystemEntities();
        jobInstructor ji;
        Controller cobj;
        public Form3(jobInstructor j,Controller c)
        {  
            InitializeComponent();
            ji = j;
            cobj = c;
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            if (fname.Text.Length == 0 || lname.Text.Length == 0 || address.Text.Length == 0 || phone.Text.Length == 0 || email.Text.Length == 0 || password.Text.Length == 0 || dept_id.Text.Length == 0 || Supervisor_id.Text.Length == 0 ||  (M.Checked == false && F.Checked == false))
            {
                MessageBox.Show("you must fill all fields");
            }
            else
            {
                if (!email.Text.Contains("@"))
                {
                    MessageBox.Show("incorrect Email");

                }
                else
                {
                    long phoneNumber;
                    int t1;
                    int t2;
                    if (!(long.TryParse(phone.Text, out phoneNumber)))
                    {
                        MessageBox.Show("Phone number must contain digits only.");
                    }
                    if (!(int.TryParse(Supervisor_id.Text, out t1)))
                    {
                        MessageBox.Show("Supervisor id number must contain digits only.");
                    }
                    if (!(int.TryParse(dept_id.Text, out t2)))
                    {
                        MessageBox.Show("department id  number must contain digits only.");
                    }
                    else
                    {
                        string Fname = fname.Text.ToString();
                        string Lname = lname.Text.ToString();
                        string Gender;
                        if (M.Checked == true)
                        {
                            Gender = "M";
                        }
                        else
                        {
                            Gender = "F";
                        }
                        string Address = address.Text.ToString();
                        string Phone = phone.Text.ToString();
                         int super = int.Parse(Supervisor_id.Text);
                        int dept = int.Parse(dept_id.Text);
                        DateTime Birth = birth.Value;
                    
                        string Email = email.Text.ToString();
                        string Password = password.Text.ToString();
                        int max=cobj.getMaxid();
                        max++;
                        int result = cobj.InsertInstructor(max,Fname, Lname, Gender,Phone,Birth,Address,Email,Password,super,dept);

                        if (result > 0)
                        {
                            MessageBox.Show("instructor inserted successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Insert failed. Please check your data.");
                        }

                        DataTable dt = cobj.getInstructor(Email, Password);
                        instructor_info.DataSource = dt;
                        instructor_info.Refresh();
                    }

                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ji.Show();
            this.Hide();
        }

        private void show_CheckedChanged(object sender, EventArgs e)
        {
            if (show.Checked)
            {
                password.PasswordChar = '\0';
            }
            else
            {
                password.PasswordChar = '*';
            }
        }
    }

     
    
}
    

