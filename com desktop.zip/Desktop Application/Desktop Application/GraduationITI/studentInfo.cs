﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraduationITI
{
    public partial class studentInfo : Form
    {
        Login log;
        string email;
        string password;
        Controller controlobj;
        jobInstructor ji;
        Quiz q;
        int id;
        public studentInfo(Login f1,string email,string password, Controller  c,jobInstructor ji,int id)
        {
            InitializeComponent();
            log = f1;
            this.email = email;
            this.password = password;
            controlobj = c;
            this.ji= ji;
            this.id = id;
           
        }

        private void DvgIns_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
             
        }

        private void button2_Click(object sender, EventArgs e)
        {   
            this.Hide();
            log.ResetFields();
            if(ji==null)
            log.Show();
            else
                ji.Show();
        }

        public void dissapeare()
        {
            btn_grade.Visible = false;
            exam.Visible = false;

        }
        private void studentInfo_Load(object sender, EventArgs e)
        {

        }

        private void btn_grade_Click(object sender, EventArgs e)
        {
            int id = controlobj.getStudentId(email, password);
            DataTable dt = controlobj.getStudentmarks(id);
            S_info.DataSource= dt;
            S_info.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            q = new Quiz(this, id, controlobj);
            q.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            profile_info();
        }

        private void profile_info()
        {
            DataTable dt;
            if (ji == null)
            {
                dt = controlobj.getStudent(email, password);
            }
            else
            {
                dt = controlobj.getInstructor(email, password);
            }
            S_info.DataSource = dt;
            S_info.Refresh();
        }
    }
}
