﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraduationITI
{
    public partial class Form4 : Form
    {
        ExaminationSystemEntities db = new ExaminationSystemEntities();
        public Form4()
        {
            InitializeComponent();
        }

        private void DvgIns_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Track tck = new Track();
            tck.Track_ID = int.Parse(txtItrack.Text);
            tck.Track_Name = txtftrackname.Text;
            db.Tracks.Add(tck);
            db.SaveChanges();
            MessageBox.Show("Data inserted Succefully");
            txtItrack.Text = " ";
            txtftrackname.Text = " ";
        }

        private void btncansel_Click(object sender, EventArgs e)
        {
            // Assuming "Form1" is your home page form
            Form1 homeForm = new Form1();
            homeForm.Show();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            int trackID = int.Parse(txtItrack.Text); // Assuming you have a textbox for entering track ID
            var trackToUpdate = db.Tracks.FirstOrDefault(t => t.Track_ID == trackID);
            if (trackToUpdate != null)
            {
                // Update properties of the existing track object
                trackToUpdate.Track_Name = txtftrackname.Text;

                // Save changes to the database
                db.SaveChanges();
                MessageBox.Show("Data updated successfully");
            }
            else
            {
                MessageBox.Show("Track with ID " + trackID + " not found");
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            int trackID = int.Parse(txtItrack.Text); // Assuming you have a textbox for entering track ID
            var trackToDelete = db.Tracks.FirstOrDefault(t => t.Track_ID == trackID);
            if (trackToDelete != null)
            {
                // Remove the track from the database
                db.Tracks.Remove(trackToDelete);

                // Save changes to the database
                db.SaveChanges();
                MessageBox.Show("Track deleted successfully");

                // Optionally, clear the textboxes after deletion
                ClearTextBoxes();
            }
            else
            {
                MessageBox.Show("Track with ID " + trackID + " not found");
            }
        }

        private void ClearTextBoxes()
        {
            txtItrack.Text = string.Empty;
            txtftrackname.Text = string.Empty;
        }
    }
    }
    

