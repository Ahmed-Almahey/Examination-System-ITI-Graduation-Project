﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace GraduationITI
{
    public partial class jobInstructor : Form
    {
        Form f;
        studentInfo info;
        string email;
        string password;
        Controller cobj;
        Login lg;
        Form f2;
        public jobInstructor(Login l, string e, string p, Controller c)
        {
            InitializeComponent();
            lg = l;
            password = p;
            email = e;
            cobj = c;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            f = new exam(this,cobj);
            f.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            info = new studentInfo(lg, email, password, cobj,this,0);
            info.dissapeare();
            info.Show();
            this.Hide();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            lg.ResetFields();
            lg.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            f2 = new Form3(this,cobj);
            f2.Show();
            this.Hide();
        }
    }
}
