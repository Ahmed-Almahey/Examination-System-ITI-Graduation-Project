﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraduationITI
{
    public partial class Login : Form
    {
        Controller controllobj;
        studentInfo info;
        Form job;
        jobInstructor ji= null;
        Form signup;
        public Login()
        {
            InitializeComponent();
            controllobj = new Controller();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (email.Text.Length == 0 || password.Text.Length == 0 || (!(inst.Checked) && !(stud.Checked)))
            {
                MessageBox.Show(" you should fill both fileds");
            }
            else
            {
                if (inst.Checked)
                {
                    int check = controllobj.checkInstructorAuthorize(email.Text.ToString(), password.Text.ToString());
                    if (check == 0)
                    {
                        MessageBox.Show(" Wrong Email or password");
                    }
                    else
                    {
                        job = new jobInstructor(this, email.Text.ToString(), password.Text.ToString(), controllobj);
                        job.Show();
                        this.Hide();
                    }
                }
                else
                {
                    int check = controllobj.checkStudentAuthorize(email.Text.ToString(), password.Text.ToString());
                    if (check == 0)
                    {
                        MessageBox.Show(" Wrong Email or password");
                    }
                    else
                    {
                        int id = controllobj.getStudentId(email.Text.ToString(), password.Text.ToString());
                        info = new studentInfo(this, email.Text.ToString(), password.Text.ToString(), controllobj,ji,id);

                        info.Show();
                        this.Hide();


                    }
                }
            }
        }
        public void ResetFields()
        {
            email.Text = "";
            password.Text = "";
            inst.Checked = false;
            stud.Checked = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            signup = new Form2(this,controllobj);
            signup.Show();
            this.Hide();
        }

        private void show_CheckedChanged(object sender, EventArgs e)
        {
            if(show.Checked==true)
            {
                password.PasswordChar = '\0';
            }
            else
            {
                password.PasswordChar = '*';
            }
        }
    }
}
    
