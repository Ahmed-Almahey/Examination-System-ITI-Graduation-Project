﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraduationITI
{
    public partial class exam : Form
    {
        Controller c;
        jobInstructor ji;
        public exam(jobInstructor ji,Controller c)
        {
            InitializeComponent();
            this.c = c;
            this.ji = ji;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string course = C_name.Text;
            int c_id = c.getCourseId(course);
            int e_id = c.Exam_id(c_id);
            DataTable dt = c.getQuestions(e_id);
            exam_V.DataSource = dt;
            exam_V.Refresh();
        }

        private void exam_Click(object sender, EventArgs e)
        {
          
        }

        private void C_name_DropDown(object sender, EventArgs e)
        {
            C_name.Items.Clear();

            DataTable dt = c.getCourses();

            foreach (DataRow row in dt.Rows)
            {
                C_name.Items.Add(row["Course_Name"].ToString());
            }
        }

        private void exam_V_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ji.Show();
            this.Hide();
        }

        private void e_box_SelectedIndexChanged(object sender, EventArgs e)
        {
            int e_id = int.Parse(e_box.Text);

            DataTable dt = c.getmarks(e_id);
            exam_V.DataSource = dt;
            exam_V.Refresh();
        }

        private void e_box_DropDown(object sender, EventArgs e)
        {
            DataTable dt = c.getExamIds();
            foreach (DataRow row in dt.Rows)
            {
                e_box.Items.Add(row["Exam_ID"].ToString());
            }
        }
    }
}
