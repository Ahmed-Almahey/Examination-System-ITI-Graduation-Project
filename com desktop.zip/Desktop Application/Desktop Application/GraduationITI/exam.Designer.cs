﻿namespace GraduationITI
{
    partial class exam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exam_V = new System.Windows.Forms.DataGridView();
            this.C_name = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.e_id = new System.Windows.Forms.Label();
            this.e_box = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.exam_V)).BeginInit();
            this.SuspendLayout();
            // 
            // exam_V
            // 
            this.exam_V.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.exam_V.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.exam_V.Location = new System.Drawing.Point(-1, 135);
            this.exam_V.Name = "exam_V";
            this.exam_V.RowHeadersWidth = 51;
            this.exam_V.RowTemplate.Height = 24;
            this.exam_V.Size = new System.Drawing.Size(1098, 347);
            this.exam_V.TabIndex = 0;
            this.exam_V.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.exam_V_CellContentClick);
            // 
            // C_name
            // 
            this.C_name.FormattingEnabled = true;
            this.C_name.Location = new System.Drawing.Point(411, 37);
            this.C_name.Name = "C_name";
            this.C_name.Size = new System.Drawing.Size(285, 24);
            this.C_name.TabIndex = 1;
            this.C_name.DropDown += new System.EventHandler(this.C_name_DropDown);
            this.C_name.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(216, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 24);
            this.label2.TabIndex = 20;
            this.label2.Text = "Course Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkRed;
            this.button2.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(891, 49);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(163, 67);
            this.button2.TabIndex = 21;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // e_id
            // 
            this.e_id.AutoSize = true;
            this.e_id.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e_id.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.e_id.Location = new System.Drawing.Point(263, 92);
            this.e_id.Name = "e_id";
            this.e_id.Size = new System.Drawing.Size(96, 24);
            this.e_id.TabIndex = 33;
            this.e_id.Text = "Exam ID";
            // 
            // e_box
            // 
            this.e_box.FormattingEnabled = true;
            this.e_box.Location = new System.Drawing.Point(411, 92);
            this.e_box.Name = "e_box";
            this.e_box.Size = new System.Drawing.Size(285, 24);
            this.e_box.TabIndex = 32;
            this.e_box.DropDown += new System.EventHandler(this.e_box_DropDown);
            this.e_box.SelectedIndexChanged += new System.EventHandler(this.e_box_SelectedIndexChanged);
            // 
            // exam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1102, 487);
            this.Controls.Add(this.e_id);
            this.Controls.Add(this.e_box);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.C_name);
            this.Controls.Add(this.exam_V);
            this.Name = "exam";
            this.Text = "exam";
            this.Click += new System.EventHandler(this.exam_Click);
            ((System.ComponentModel.ISupportInitialize)(this.exam_V)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView exam_V;
        private System.Windows.Forms.ComboBox C_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label e_id;
        private System.Windows.Forms.ComboBox e_box;
    }
}