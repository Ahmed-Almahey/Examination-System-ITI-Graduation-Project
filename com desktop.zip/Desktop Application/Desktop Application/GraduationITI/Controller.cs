﻿using GraduationITI;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace GraduationITI
{
    public class Controller
    {

        DBManager dbMan;

        public Controller()
        {
            dbMan = new DBManager();
        }

        public DataTable SelectAllDepartment()
        {
            string query = "SELECT d.Dname   FROM Employee e, Department d   WHERE e.Dno = d.Dnumber   GROUP BY d.Dname ORDER BY COUNT(e.Dno) DESC;";
            return dbMan.ExecuteReader(query);
        }

        public DataTable selectDepart()
        {
            string query = "SELECT d.Dname,d.Dnumber   FROM  Department d ;";
            return dbMan.ExecuteReader(query);
        }

        public int avg(int num)
        {
            string query = "SELECT AVG(salary) From Employee where Dno=" + num + ";";

            return (int)dbMan.ExecuteScalar(query);
        }


        public DataTable SelectAllEmployee()
        {


            string query = "SELECT d.Dname, e.Fname,e.Minit,e.Lname  FROM Employee e, Department d   WHERE e.Dno = d.Dnumber   ;";
            return dbMan.ExecuteReader(query);
        }

        public int checkStudentAuthorize(string email,string password)
        {  string q= "Select count(*) From Student where Email= '"+ email +"' AND password = '"+ password + "'";
            return (int)dbMan.ExecuteScalar(q);
        }

        public int checkInstructorAuthorize(string email, string password)
        {
            string q = "Select count(*) From Instructor where Email= '" + email + "' AND password = '" + password + "'";
            return (int)dbMan.ExecuteScalar(q);
        }

        public DataTable getStudent(string email, string password)
        {
            string q = "Select * From Student where Email= '" + email + "' AND password = '" + password + "'";
            return dbMan.ExecuteReader(q);
        }

        public DataTable getInstructor(string email, string password)
        {
            string q = "Select * From Instructor where Email= '" + email + "' AND password = '" + password + "'";
            return dbMan.ExecuteReader(q);
        }

        public DataTable getCourses()
        {
            string q = "Select Course_Name From Courses ";
            return dbMan.ExecuteReader(q);
        }

        public int getCourseId(string name)
        {
            string q = "Select Course_ID From Courses where Course_Name= '" + name + "'";
            return (int)dbMan.ExecuteScalar(q);
        }
        public int getExamId(int ID,int course)
        {
            DataTable dt;
            string qr = "SELECT Exam_ID " +
                        "FROM student_Exam " +
                        "WHERE Student_ID = " + ID;
            dt = dbMan.ExecuteReader(qr);

            List<string> ids = new List<string>();
            foreach (DataRow row in dt.Rows)
            {
                ids.Add(row["Exam_ID"].ToString());
            }

            string idList = string.Join(",", ids);

            string q = "SELECT TOP 1 Exam_ID FROM Exam WHERE Course_ID = " + course +
                       (ids.Count > 0 ? " AND Exam_ID NOT IN (" + idList + ")" : "");

            object result = dbMan.ExecuteScalar(q);
            return result != null ? Convert.ToInt32(result) : 0;
        }


        public DataTable getQuestions(int ID)
        {
            string q = "Select Question_ID From Exam_Quastions where Exam_ID = '" + ID + "'";
            DataTable idTable = dbMan.ExecuteReader(q);
            if (idTable.Rows.Count == 0)
                return null;
            List<string> ids = new List<string>();
            foreach (DataRow row in idTable.Rows)
            {
                ids.Add(row["Question_ID"].ToString()); 
            }

            string idList = string.Join(",", ids);

            string query = $"SELECT Question_Text FROM Questions WHERE Question_ID IN ({idList})";

            return dbMan.ExecuteReader(query);
        }
        public DataTable getExamIds()
        {
            string q = "Select Exam_ID From Exam ";
            return dbMan.ExecuteReader(q);
        }

        public DataTable getmarks(int ID)
        {
            string q = "SELECT fname + ' ' + lname AS [full name], SUM(grade) AS Marks " +
               "FROM Answer a, student s " +
               "WHERE s.Student_ID = a.Student_ID AND Exam_ID = " + ID + " " +
               "GROUP BY fname + ' ' + lname";
            return dbMan.ExecuteReader(q);
        }

        public int getStudentId(string email, string password)
        {
            string q = "Select Student_ID From Student where Email= '" + email + "' AND password = '" + password + "'";
            return (int)dbMan.ExecuteScalar(q);
        }


        public DataTable getStudentmarks(int ID)
        {
            string q = "SELECT Student_ID,Exam_ID,SUM(grade) AS Marks " +
               "FROM Answer " +
               "WHERE  Student_ID = " + ID + " " +
               "GROUP BY Student_ID , Exam_ID";
            return dbMan.ExecuteReader(q);
        }

        public DataTable gettrackname()
        {
            string q = "Select track_ID,track_Name From track ";
            return dbMan.ExecuteReader(q);
        }

        public int InsertStudent(string fname, string lname, string gender, string company, string postion,
                         string address, string phone, bool freelance, DateTime birth, string email, string password, int trackid)
        {
            try
            {
                string query = "INSERT INTO Student (Fname, Lname, Gender, Company_Name, Position, Address, Phone, freelance, BirthDate, Email, Password, Track_ID) " +
                               "VALUES (@Fname, @Lname, @Gender, @Company, @Postion, @Address, @Phone, @Freelance, @BirthDate, @Email, @Password, @TrackID)";

                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@Fname", fname);
                cmd.Parameters.AddWithValue("@Lname", lname);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Company", company);
                cmd.Parameters.AddWithValue("@Postion", postion);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@Phone", phone);
                cmd.Parameters.AddWithValue("@Freelance", freelance);
                cmd.Parameters.AddWithValue("@BirthDate", birth);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Password", password);
                cmd.Parameters.AddWithValue("@TrackID", trackid);

                return dbMan.ExecuteNonQuery(cmd); 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return 0;
            }
        }

        public DataTable getcousestudent(int id )
        {
            string q = "SELECT course_id FROM student_courses WHERE  Student_ID = " + id ;
            DataTable dt= dbMan.ExecuteReader(q);
            List<string> ids = new List<string>();
            foreach (DataRow row in dt.Rows)
            {
                ids.Add(row["course_id"].ToString());
            }
            string idList = string.Join(",", ids);

            string query = $"SELECT Course_Name FROM Courses WHERE course_ID IN ({idList})";
            return dbMan.ExecuteReader(query);
        }

        public DataTable getAnswerQuestions(int ID)
        {
            string q = "Select Question_ID From Exam_Quastions where Exam_ID = '" + ID + "'";
            DataTable idTable = dbMan.ExecuteReader(q);
            if (idTable.Rows.Count == 0)
                return null;
            List<string> ids = new List<string>();
            foreach (DataRow row in idTable.Rows)
            {
                ids.Add(row["Question_ID"].ToString());
            }

            string idList = string.Join(",", ids);

            string query = $"SELECT Model_Answer FROM Questions WHERE Question_ID IN ({idList})";

            return dbMan.ExecuteReader(query);
        }

        public int InsertInstructor(int id,string fname, string lname, string gender,
                         string phone, DateTime birth, string address, string email, string password,int super,int department)
        {
            
            try
            {
                string query = "INSERT INTO Instructor (Instructor_ID,Fname, Lname, Gender, Phone,BirthDate,Address, Email, Password,supervisor_id,department_id) " +
                               "VALUES (@Instructor_ID,@Fname, @Lname, @Gender, @Phone,@BirthDate,@Address, @Email, @Password,@supervisor_id,@department_id)";

                SqlCommand cmd = new SqlCommand(query);

                cmd.Parameters.AddWithValue("@Instructor_ID",id);
                cmd.Parameters.AddWithValue("@Fname", fname);
                cmd.Parameters.AddWithValue("@Lname", lname);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@Phone", phone);
                cmd.Parameters.AddWithValue("@BirthDate", birth);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Password", password);
                cmd.Parameters.AddWithValue("@supervisor_id",super);
                cmd.Parameters.AddWithValue("@department_id",department);

                return dbMan.ExecuteNonQuery(cmd);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return 0;
            }
        }
        public int getMaxid()
        {
            string q = "Select Max(Instructor_ID) From Instructor ";
            return (int)dbMan.ExecuteScalar(q);
        }


        public int insertStudentAnswer(int s_id,int Q_id,int E_id,int Grade,string S_answer)
        {
            try
            {
                string query = "INSERT INTO Answer (Student_ID,Question_ID, Exam_ID, Grade,Student_Answer)" +
                    "VALUES (@Student_ID,@Question_ID, @Exam_ID, @Grade, @Student_Answer)";

                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@Student_ID", s_id);
                cmd.Parameters.AddWithValue("@Question_ID", Q_id);
                cmd.Parameters.AddWithValue("@Exam_ID", E_id);
                cmd.Parameters.AddWithValue("@Grade", Grade);
                cmd.Parameters.AddWithValue("@Student_Answer", S_answer);

                return dbMan.ExecuteNonQuery(cmd);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return 0;
            }

        }

        public DataTable Questions_IDS(int ID)
        {
            string q = "Select Question_ID From Exam_Quastions where Exam_ID = '" + ID + "'";
            DataTable idTable = dbMan.ExecuteReader(q);
            return idTable;
        }

        public int insertexam_student(int s_id,int E_id)
        {
            try
            {
                string query = "INSERT INTO student_exam (Student_ID, Exam_ID)" +
                    "VALUES (@Student_ID, @Exam_ID)";

                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@Student_ID", s_id);
                cmd.Parameters.AddWithValue("@Exam_ID", E_id);
                return dbMan.ExecuteNonQuery(cmd);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return 0;
            }

        }

        public int Exam_id(int ID)
        {
            string q = "select Exam_ID from Exam where course_id ='" + ID + "'";;
            return (int)dbMan.ExecuteScalar(q);
        }



    }
}







