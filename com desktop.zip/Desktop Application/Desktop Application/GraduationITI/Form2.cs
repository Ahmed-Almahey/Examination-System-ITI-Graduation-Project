﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace GraduationITI
{
    public partial class Form2 : Form
    {
        ExaminationSystemEntities db = new ExaminationSystemEntities();
        Login lg;
        Controller cobj;
        int trackId;
        public Form2(Login l,Controller c)
        {
            InitializeComponent();
            lg = l;
            cobj = c;
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            s.Student_ID = int.Parse(fname.Text);
            s.Fname = lname.Text;
            s.Lname = phone.Text;
            s.Phone = address.Text;
            s.Address = email.Text;
            s.Position = password.Text;
            db.Students.Add(s);
            db.SaveChanges();
            MessageBox.Show("Data inserted Succefully");
            fname.Text = " ";
            lname.Text = "  ";
            lname.Text = " ";
            phone.Text = " ";
            address.Text = "  ";
            email.Text = " ";
            password.Text = " ";
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            int studentID = int.Parse(fname.Text); // Assuming you have a textbox for entering student ID
            var studentToUpdate = db.Students.FirstOrDefault(s => s.Student_ID == studentID);
            if (studentToUpdate != null)
            {
                // Update properties of the existing student object
                studentToUpdate.Fname = lname.Text;
                studentToUpdate.Lname = phone.Text;
                studentToUpdate.Phone = address.Text;
                studentToUpdate.Address = email.Text;
                studentToUpdate.Position = password.Text;
                // Save changes to the database
                db.SaveChanges();
                MessageBox.Show("Data updated successfully");
                fname.Text = " ";
                lname.Text = "  ";
                lname.Text = " ";
                phone.Text = " ";
                address.Text = "  ";
                email.Text = " ";
                password.Text = " ";
            }
            else
            {
                MessageBox.Show("Student with ID " + studentID + " not found");
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            int studentID = int.Parse(fname.Text); // Assuming you have a textbox for entering student ID
            var studentToDelete = db.Students.FirstOrDefault(s => s.Student_ID == studentID);
            if (studentToDelete != null)
            {
                // Remove the student from the database
                db.Students.Remove(studentToDelete);

                // Save changes to the database
                db.SaveChanges();
                MessageBox.Show("Student deleted successfully");

                // Optionally, clear the textboxes after deletion
                ClearTextBoxes();
            }
            else
            {
                MessageBox.Show("Student with ID " + studentID + " not found");
            }
        }

        private void ClearTextBoxes()
        {
            fname.Text = string.Empty;
            lname.Text = string.Empty;
            phone.Text = string.Empty;
            address.Text = string.Empty;
            email.Text = string.Empty;
            password.Text = string.Empty;
           
            postion.Text = string.Empty;
            
        
        }

        private void btncansel_Click(object sender, EventArgs e)
        {
            this.Hide();

            // Assuming "Form1" is your home page form
            Form1 homeForm = new Form1();
            homeForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lg.ResetFields();
            lg.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(fname.Text.Length==0 || lname.Text.Length == 0 || address.Text.Length == 0 || phone.Text.Length == 0 || email.Text.Length == 0|| password.Text.Length == 0 || company.Text.Length == 0 || postion.Text.Length == 0 || track.Text.Length==0 ||(M.Checked==false && F.Checked == false))
            {
                MessageBox.Show("you must fill all fields");
            }
            else
            {  
                 if(!email.Text.Contains("@"))
                 {
                    MessageBox.Show("incorrect Email");

                 }
                else
                {
                    long phoneNumber;
                    if (!(long.TryParse(phone.Text, out phoneNumber)))
                    {
                        MessageBox.Show("Phone number must contain digits only.");
                    }
                    else
                    {
                        string Fname =fname.Text.ToString();
                        string Lname = lname.Text.ToString();
                        string Gender;
                        if(M.Checked==true)
                        {
                             Gender ="M";
                        }
                        else 
                        { 
                             Gender ="F";
                        }
                        string Company = company.Text.ToString();
                        string Postion = postion.Text.ToString();
                        string Address = address.Text.ToString();
                        string Phone = phone.Text.ToString(); 
                        DateTime Birth=birth.Value ;
                        bool Freelance;
                        if (freelance.Checked == false)
                        {
                             Freelance= false;
                        }
                        else
                        {
                            Freelance= true;
                        }
                        string Email =email.Text.ToString();
                        string Password =password.Text.ToString();

                        int result = cobj.InsertStudent(Fname, Lname, Gender, Company, Postion,
                                          Address, Phone, Freelance, Birth, Email, Password, trackId);

                        if (result > 0)
                        {
                            MessageBox.Show("Student inserted successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Insert failed. Please check your data.");
                        }

                        DataTable dt = cobj.getStudent(Email, Password);
                        signInfo.DataSource = dt;
                        signInfo.Refresh();
                    }

                }

            }
        }

        private void track_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (track.SelectedValue != null && track.SelectedValue is int)
            {
                trackId = Convert.ToInt32(track.SelectedValue);
            }
        }

        private void track_DropDown(object sender, EventArgs e)
        {
            DataTable dt = cobj.gettrackname();
            track.DataSource = dt;
            track.DisplayMember = "track_Name";  
            track.ValueMember = "track_ID";
        }

        private void show_CheckedChanged(object sender, EventArgs e)
        {
            if (show.Checked)
            {
                password.PasswordChar = '\0';
            }
            else
            {
                password.PasswordChar = '*';  
            }
        }
    }
    }

