﻿namespace GraduationITI
{
    partial class studentInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(studentInfo));
            this.S_info = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_grade = new System.Windows.Forms.Button();
            this.exam = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.S_info)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // S_info
            // 
            this.S_info.AccessibleName = "";
            this.S_info.BackgroundColor = System.Drawing.Color.White;
            this.S_info.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.S_info.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.S_info.Location = new System.Drawing.Point(3, 121);
            this.S_info.Name = "S_info";
            this.S_info.RowHeadersWidth = 51;
            this.S_info.RowTemplate.Height = 26;
            this.S_info.Size = new System.Drawing.Size(1018, 317);
            this.S_info.TabIndex = 26;
            this.S_info.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DvgIns_CellContentClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(205, 89);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkRed;
            this.button2.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(849, 26);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(163, 67);
            this.button2.TabIndex = 28;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_grade
            // 
            this.btn_grade.BackColor = System.Drawing.Color.DarkRed;
            this.btn_grade.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_grade.ForeColor = System.Drawing.Color.White;
            this.btn_grade.Location = new System.Drawing.Point(655, 26);
            this.btn_grade.Name = "btn_grade";
            this.btn_grade.Size = new System.Drawing.Size(163, 67);
            this.btn_grade.TabIndex = 29;
            this.btn_grade.Text = "My Grades";
            this.btn_grade.UseVisualStyleBackColor = false;
            this.btn_grade.Click += new System.EventHandler(this.btn_grade_Click);
            // 
            // exam
            // 
            this.exam.BackColor = System.Drawing.Color.DarkRed;
            this.exam.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exam.ForeColor = System.Drawing.Color.White;
            this.exam.Location = new System.Drawing.Point(282, 26);
            this.exam.Name = "exam";
            this.exam.Size = new System.Drawing.Size(163, 67);
            this.exam.TabIndex = 30;
            this.exam.Text = "Take Exam";
            this.exam.UseVisualStyleBackColor = false;
            this.exam.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkRed;
            this.button3.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(466, 26);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(163, 67);
            this.button3.TabIndex = 31;
            this.button3.Text = "profile";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // studentInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1033, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.exam);
            this.Controls.Add(this.btn_grade);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.S_info);
            this.Name = "studentInfo";
            this.Text = "studentInfo";
            this.Load += new System.EventHandler(this.studentInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.S_info)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView S_info;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_grade;
        private System.Windows.Forms.Button exam;
        private System.Windows.Forms.Button button3;
    }
}