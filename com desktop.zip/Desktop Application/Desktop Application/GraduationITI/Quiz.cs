﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace GraduationITI
{
    public partial class Quiz : Form
    {
        studentInfo ss;
        int id;
        Controller cobj;
        int e_id;
        TimeSpan timeRemaining = TimeSpan.FromMinutes(10);

        public Quiz(studentInfo s, int id, Controller c)
        {

            InitializeComponent();
            ss = s;
            this.id = id;
            this.cobj = c;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Course = course.Text;
            int c_id = cobj.getCourseId(Course);
            e_id = cobj.getExamId(id,c_id);
            if (e_id == 0)
            {
                MessageBox.Show("there is no Exams for this Course you didnt take it");
            }
            else
            {
                DataTable dt = cobj.getQuestions(e_id);
                exam_V.DataSource = dt;
                exam_V.Refresh();
                lbltimer.Text = timeRemaining.ToString(@"mm\:ss");
                timer.Start();
            }
        }

        private void comboBox1_DropDown(object sender, EventArgs e)
        {
            course.Items.Clear();

            DataTable dt = cobj.getcousestudent(id);

            foreach (DataRow row in dt.Rows)
            {
                course.Items.Add(row["Course_Name"].ToString());
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ss.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (course.Text.Length == 0 )
            {
                MessageBox.Show("you must select course ");
            }
            else if(e_id==0)
            {
                MessageBox.Show("you must select other course ");
            
            }
            else
            {
                quiz_handle();
            }

            // first put in student exam so can prevent the exam he takes already
            //_

        }

        private char helperf(GroupBox groupBox)
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is RadioButton rb && rb.Checked)
                {
                    return Convert.ToChar(rb.Text); // assuming radio button text is like "A", "B", etc.
                }
            }

            // Return default or error character if nothing is selected
            return ' ';
        }

        private string help2(char A)
        {
            string ans;
            if (A == 'T')
            {
                ans = "True";
            }
            else if (A == 'F')
            {
                ans = "False";
            }
            else
            {
                ans = A.ToString();
            }
            return ans;
        }

        private void Quiz_Load(object sender, EventArgs e)
        {
           
        }

        private void timer_Tick_1(object sender, EventArgs e)
        {   
            if (timeRemaining.TotalSeconds > 0)
            {
                timeRemaining = timeRemaining.Subtract(TimeSpan.FromSeconds(1));
                lbltimer.Text = timeRemaining.ToString(@"mm\:ss");
            }
            else
            {
                timer.Stop();
                MessageBox.Show("Time's up! The exam will be submitted.", "Exam Finished", MessageBoxButtons.OK, MessageBoxIcon.Information);
                quiz_handle();

            }
        }

        private void quiz_handle()
        {


            char A1 = helperf(groupBox1);
            char A2 = helperf(groupBox2);
            char A3 = helperf(groupBox3);
            char A4 = helperf(groupBox4);
            char A5 = helperf(groupBox5);
            char A6 = helperf(groupBox6);
            char A7 = helperf(groupBox7);
            char A8 = helperf(groupBox8);
            char A9 = helperf(groupBox9);
            char A10 = helperf(groupBox10);


            int x = cobj.insertexam_student(id, e_id);
            DataTable dts = cobj.Questions_IDS(e_id);
            //if (dts.Rows.Count == 0)
            //{

            //}
            List<string> ids = new List<string>();
            foreach (DataRow row in dts.Rows)
            {
                ids.Add(row["Question_ID"].ToString());
            }



            DataTable dt = cobj.getAnswerQuestions(e_id);
            List<string> answers = new List<string>();
            foreach (DataRow row in dt.Rows)
            {
                answers.Add(row["Model_Answer"].ToString());
            }
            string ans;
            int correctCount = 0;

            ans = help2(A1);
            if (answers[0][0] == A1)
            {
                if (answers[0][0] == 'T' || answers[0][0] == 'F')
                {
                    correctCount += 2;
                    cobj.insertStudentAnswer(id, int.Parse(ids[0]), e_id, 2, ans);
                }
                else
                {
                    correctCount += 3;
                    cobj.insertStudentAnswer(id, int.Parse(ids[0]), e_id, 3, ans);
                }

            }
            else
            {
                cobj.insertStudentAnswer(id, int.Parse(ids[0]), e_id, 0, ans);
            }

            ans = help2(A2);
            if (answers[1][0] == A2)
            {
                if (answers[1][0] == 'T' || answers[1][0] == 'F')
                {
                    correctCount += 2;
                    cobj.insertStudentAnswer(id, int.Parse(ids[1]), e_id, 2, ans);
                }
                else
                {
                    correctCount += 3;
                    cobj.insertStudentAnswer(id, int.Parse(ids[1]), e_id, 3, ans);
                }

            }
            else
            {
                cobj.insertStudentAnswer(id, int.Parse(ids[1]), e_id, 0, ans);
            }

            ans = help2(A3);
            if (answers[2][0] == A3)
            {
                if (answers[2][0] == 'T' || answers[2][0] == 'F')
                {
                    correctCount += 2;
                    cobj.insertStudentAnswer(id, int.Parse(ids[2]), e_id, 2, ans);
                }
                else
                {
                    correctCount += 3;
                    cobj.insertStudentAnswer(id, int.Parse(ids[2]), e_id, 3, ans);
                }

            }
            else
            {
                cobj.insertStudentAnswer(id, int.Parse(ids[2]), e_id, 0, ans);
            }

            ans = help2(A4);
            if (answers[3][0] == A4)
            {
                if (answers[3][0] == 'T' || answers[3][0] == 'F')
                {
                    correctCount += 2;
                    cobj.insertStudentAnswer(id, int.Parse(ids[3]), e_id, 2, ans);
                }
                else
                {
                    correctCount += 3;
                    cobj.insertStudentAnswer(id, int.Parse(ids[3]), e_id, 3, ans);
                }

            }
            else
            {
                cobj.insertStudentAnswer(id, int.Parse(ids[3]), e_id, 0, ans);
            }

            ans = help2(A5);
            if (answers[4][0] == A5)
            {
                if (answers[4][0] == 'T' || answers[4][0] == 'F')
                {
                    correctCount += 2;
                    cobj.insertStudentAnswer(id, int.Parse(ids[4]), e_id, 2, ans);
                }
                else
                {
                    correctCount += 3;
                    cobj.insertStudentAnswer(id, int.Parse(ids[4]), e_id, 3, ans);
                }

            }
            else
            {
                cobj.insertStudentAnswer(id, int.Parse(ids[4]), e_id, 0, ans);
            }

            ans = help2(A6);
            if (answers[5][0] == A6)
            {
                if (answers[5][0] == 'T' || answers[5][0] == 'F')
                {
                    correctCount += 2;
                    cobj.insertStudentAnswer(id, int.Parse(ids[5]), e_id, 2, ans);
                }
                else
                {
                    correctCount += 3;
                    cobj.insertStudentAnswer(id, int.Parse(ids[5]), e_id, 3, ans);
                }

            }
            else
            {
                cobj.insertStudentAnswer(id, int.Parse(ids[5]), e_id, 0, ans);
            }

            ans = help2(A7);
            if (answers[6][0] == A7)
            {
                if (answers[6][0] == 'T' || answers[6][0] == 'F')
                {
                    correctCount += 2;
                    cobj.insertStudentAnswer(id, int.Parse(ids[6]), e_id, 2, ans);
                }
                else
                {
                    correctCount += 3;
                    cobj.insertStudentAnswer(id, int.Parse(ids[6]), e_id, 3, ans);
                }

            }
            else
            {
                cobj.insertStudentAnswer(id, int.Parse(ids[6]), e_id, 0, ans);
            }

            ans = help2(A8);
            if (answers[7][0] == A8)
            {
                if (answers[7][0] == 'T' || answers[7][0] == 'F')
                {
                    correctCount += 2;
                    cobj.insertStudentAnswer(id, int.Parse(ids[7]), e_id, 2, ans);
                }
                else
                {
                    correctCount += 3;
                    cobj.insertStudentAnswer(id, int.Parse(ids[7]), e_id, 3, ans);
                }

            }
            else
            {
                cobj.insertStudentAnswer(id, int.Parse(ids[7]), e_id, 0, ans);
            }

            ans = help2(A9);
            if (answers[8][0] == A9)
            {
                if (answers[8][0] == 'T' || answers[8][0] == 'F')
                {
                    correctCount += 2;
                    cobj.insertStudentAnswer(id, int.Parse(ids[8]), e_id, 2, ans);
                }
                else
                {
                    correctCount += 3;
                    cobj.insertStudentAnswer(id, int.Parse(ids[8]), e_id, 3, ans);
                }

            }
            else
            {
                cobj.insertStudentAnswer(id, int.Parse(ids[8]), e_id, 0, ans);
            }

            ans = help2(A10);
            if (answers[9][0] == A10)
            {
                if (answers[9][0] == 'T' || answers[9][0] == 'F')
                {
                    correctCount += 2;
                    cobj.insertStudentAnswer(id, int.Parse(ids[9]), e_id, 2, ans);
                }
                else
                {
                    correctCount += 3;
                    cobj.insertStudentAnswer(id, int.Parse(ids[9]), e_id, 3, ans);
                }

            }
            else
            {
                cobj.insertStudentAnswer(id, int.Parse(ids[9]), e_id, 0, ans);
            }

            ss.Show();
            MessageBox.Show("your Mark is " + correctCount + "out of 25");
            this.Hide();
        }
    }
    
}
